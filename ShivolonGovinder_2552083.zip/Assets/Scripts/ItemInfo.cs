using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class ItemInfo : MonoBehaviour
{
    [SerializeField] InventoryManager invenMan;
    [SerializeField] Items itemInfo;
    [SerializeField] TextMeshProUGUI itemCost;
    private Image itemSprite;


    // Start is called before the first frame update
    void Start()
    {
        itemSprite = GetComponentInChildren<Image>();
        itemSprite.sprite = itemInfo.itemSprite;
        itemCost.text = itemInfo.cost.ToString();
    }

    public void BuyItem()
    {
        invenMan.AddItem(itemInfo);
    }

    public void SellItem()
    {
        invenMan.RemoveItem(itemInfo);
    }
}



