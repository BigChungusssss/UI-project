using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class DescriptionBox : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler
{
    public GameObject descriptionBox;
    public GameObject descriptionText;

    private void Start()
    {
        descriptionBox.SetActive(false);
        descriptionText.SetActive(false);
    }

    public void OnPointerEnter(PointerEventData eventData)
    {
        descriptionBox.SetActive(true);
        descriptionText.SetActive(true);
        //RectTransform rectTransform = descriptionBox.GetComponent<RectTransform>();
        //rectTransform.position = transform.position + new Vector3(0f, rectTransform.rect.height);
    }

    public void OnPointerExit(PointerEventData eventData)
    {
        descriptionBox.SetActive(false);
        descriptionText.SetActive(false);
    }
}
