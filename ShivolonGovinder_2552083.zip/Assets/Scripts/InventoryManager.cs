using System.Collections;
using System.Collections.Generic;
using System.Linq;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class InventoryManager : MonoBehaviour
{
    public List<InventorySlot> inventorySlotsList = new List<InventorySlot>();
    
    public GameObject inventoryItemPrefab;
    public GameObject inventorySlotPrefab;
    
    public int maxStack = 5;
    
    public int balance = 1000;
    public TextMeshProUGUI balanceText;
    
    public Image chestImage;
    public int chestUpgradeCost = 50;
    public GameObject chestUpgrade;

    public int inventoryUpgradeCost = 70;
    public Image inventoryImage;
    public GameObject inventoryUpgrade;

    public GameObject messages;
    public TextMeshProUGUI errorText;

    public static int listCount;

    

    public bool AddItem(Items item)
    {
        bool fullBackpack = true;
        listCount = inventorySlotsList.Count;
        if (balance >= item.cost)
        { 
            balanceText.text = balance.ToString();

            for (int i = 0; i < listCount; i++)
            {
                InventorySlot slot = inventorySlotsList[i];
                InventoryItem itemInSlot = slot.GetComponentInChildren<InventoryItem>();

                if (itemInSlot != null && itemInSlot.item == item && itemInSlot.Count < maxStack && item.stackable)
                {
                    itemInSlot.Count++;
                    itemInSlot.RefreshCount();
                    balance -= item.cost;
                    balanceText.text = balance.ToString();
                    fullBackpack = false;
                    return true;
                }
            }

            for (int i = 0; i < listCount; i++)
            {
                InventorySlot slot = inventorySlotsList[i];
                InventoryItem itemInSlot = slot.GetComponentInChildren<InventoryItem>();

                if (itemInSlot == null)
                {
                    SpawnNewItem(item, slot);
                    balance -= item.cost;
                    balanceText.text = balance.ToString();
                    fullBackpack = false;
                    return true;
                }
            }
        }
        else if(balance < item.cost)
        {
            DisplayErrorMessage("You are a broke boy");
            return false;
        }

        if (fullBackpack)
        {
            DisplayErrorMessage("Dont buy too much");
        }
       
        return false;


    }

    public bool RemoveItem(Items item)
    {
        listCount = inventorySlotsList.Count;

        for (int i = 0; i < listCount; i++)
        {
            InventorySlot slot = inventorySlotsList[i];
            InventoryItem itemInSlot = slot.GetComponentInChildren<InventoryItem>();

            if (itemInSlot != null && itemInSlot.item == item && itemInSlot.Count > 0)
            {
                balance += item.cost;
                balanceText.text = balance.ToString();
                itemInSlot.Count--;
                itemInSlot.RefreshCount();
                if (itemInSlot.Count == 0)
                {
                    Destroy(itemInSlot.gameObject);
                }
                return true;
            }
        }
        DisplayErrorMessage("its not there");
        return false;
    }

    public void UpgradeChest()
    {
        if (balance >= chestUpgradeCost)
        {
            balance -= chestUpgradeCost;
            balanceText.text = balance.ToString();
            RectTransform chestRectTransform = chestImage.GetComponent<RectTransform>();
            chestRectTransform.sizeDelta = new Vector2(600, 750);
            chestUpgrade.SetActive(false);

            for (int i = 0; i < 4; i++)
            {
                Instantiate(inventorySlotPrefab, chestImage.transform);

            }
        }
        else
        {
            DisplayErrorMessage("You are a broke boy");
        }
    }

    public void UpgradeInventory()
    {
        listCount = inventorySlotsList.Count;

        if (balance >= inventoryUpgradeCost)
        {
            balance -= inventoryUpgradeCost;
            balanceText.text = balance.ToString();
            inventoryUpgrade.SetActive(false);
            RectTransform inventoryRectTransform = inventoryImage.GetComponent<RectTransform>();
            Vector2 newSizeDelta = inventoryRectTransform.sizeDelta;
            newSizeDelta.y += 150;
            inventoryRectTransform.sizeDelta = newSizeDelta;

            for (int i = 0; i < 5; i++)
            {
                GameObject inventoryUpgradeSlot = Instantiate(inventorySlotPrefab, inventoryImage.transform);
                inventorySlotsList.Add(inventoryUpgradeSlot.GetComponent<InventorySlot>());
            }
        }
        else
        {
            DisplayErrorMessage("You are a broke boy2");
        }
    }

    public void SpawnNewItem(Items item, InventorySlot slot)
    {
        GameObject newItemGo = Instantiate(inventoryItemPrefab, slot.transform);
        InventoryItem inventoryItem = newItemGo.GetComponent<InventoryItem>();
        inventoryItem.InitialiseItem(item);
    }

    public void DisplayErrorMessage(string message)
    {
        messages.SetActive(true);
        errorText.text = message;
    }

}
